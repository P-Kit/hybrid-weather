import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

void main() async {
  await dotenv.load(fileName: ".env");
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CityListPage(),
    );
  }
}

class CityListPage extends StatelessWidget {
  final List<String> cities = ['Bangkok', 'London', 'New York', 'Tokyo'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("City Weather"),
      ),
      body: ListView.builder(
        itemCount: cities.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(cities[index]),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => WeatherDetailPage(cityName: cities[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class WeatherDetailPage extends StatelessWidget {
  final String cityName;

  const WeatherDetailPage({Key? key, required this.cityName}) : super(key: key);

  Future<Map<String, dynamic>> fetchWeather() async {
    String apiKey = dotenv.env['API_KEY'] ?? '';
    var response = await http.get(Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather?q=$cityName&units=metric&appid=$apiKey'));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load weather data');
    }
  }

  String getWeatherIcon(String weatherMain) {
    switch (weatherMain.toLowerCase()) {
      case 'clear':
        return 'assets/sunny.png';
      case 'clouds':
        return 'assets/cloudy.png';
      case 'rain':
        return 'assets/rainy.png';
      default:
        return 'assets/default.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Weather in $cityName"),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchWeather(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return const Center(child: Text('Error loading weather data'));
          } else {
            var data = snapshot.data!;
            var weatherMain = data['weather'][0]['main'];
            var temp = data['main']['temp'];
            var tempMin = data['main']['temp_min'];
            var tempMax = data['main']['temp_max'];
            var pressure = data['main']['pressure'];
            var humidity = data['main']['humidity'];
            var seaLevel = data['main']['sea_level'] ?? 'N/A';
            var clouds = data['clouds']['all'];
            var rain = data['rain']?['1h'] ?? '0';
            var sunset = DateTime.fromMillisecondsSinceEpoch(data['sys']['sunset'] * 1000);

            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(getWeatherIcon(weatherMain)),
                  Text('City: $cityName', style: const TextStyle(fontSize: 24)),
                  Text('Current Temp: $temp°C'),
                  Text('Temp Min: $tempMin°C'),
                  Text('Temp Max: $tempMax°C'),
                  Text('Pressure: $pressure hPa'),
                  Text('Humidity: $humidity%'),
                  Text('Sea Level: $seaLevel m'),
                  Text('Clouds: $clouds%'),
                  Text('Rain (1h): $rain mm'),
                  Text('Sunset: ${sunset.hour}:${sunset.minute}'),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
